﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class motion : MonoBehaviour {

	public Transform Masses;
	public float K;
	public float initdx;
	public float initdy;
	public Transform walls;
	
	private float dx;
	private float dy;
	private float ddx;
	private float ddy;
	
	
	
	// Use this for initialization
	void Start () {
		dx = initdx;
		dy = initdy;
		
	}
	
	void onCollisionEnter(Collision walls) {
		Debug.Log (gameObject.name + walls.gameObject.name);
	}
	
	void OnTriggerEnter(Collider other) {
		Debug.Log (gameObject.name + walls.gameObject.name);
	}
	


	
	// Update is called once per frame
	void FixedUpdate () {
		ddx = 0.0f;
		ddy = 0.0f;
		
		float potentialEnergy = 0.0f;
		for (int i = 0; i < Masses.childCount; i++) {
			Transform childTransform = Masses.GetChild(i).transform;
			//Debug.Log( " "+ childTransform.position.x + " "+ childTransform.position.y);
			float xdist = transform.position.x - childTransform.position.x;
			float ydist = transform.position.y - childTransform.position.y;
			float dist = Mathf.Sqrt(xdist*xdist + ydist*ydist);
			ddx += -xdist/dist * 1.0f/(dist*dist) * K;
			ddy += -ydist/dist * 1.0f/(dist*dist) * K;
			potentialEnergy -= K / dist; 
		}
		dx = dx + ddx;
		dy = dy + ddy;
		float kineticEnergy = K * (dx*dx + dy*dy) / 2.0f;
		float totalEnergy = potentialEnergy + kineticEnergy;
		Debug.Log("" + potentialEnergy + " " + kineticEnergy + " " + totalEnergy);
		transform.position = new Vector3(transform.position.x + dx, 
										 transform.position.y + dy, 0.0f);
		
	}
}
